# eecs117hw3

Frankii Tang  38637021
Nathan Le     37577940  
